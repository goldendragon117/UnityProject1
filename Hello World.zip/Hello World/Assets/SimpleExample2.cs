﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleExample2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
        //uses the Debug function built in Unity. 
        Debug.Log("Hello World!!");//prints a text in the console window 
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
